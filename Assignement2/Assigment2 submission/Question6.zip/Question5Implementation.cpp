/*
“We certify that this submission is the original work of members of the group and meets 
the Faculty's Expectations of Originality”
*/
// Holsonikov Dorisca
//Id:40316045
// William Huynh
//Id:40319618

/*
The implemetation of question 5 can be seen in the cpp files , for date.cpp/date.hpp, flight.cpp/flight.hpp and testflight.cpp/testglight.hpp
*/